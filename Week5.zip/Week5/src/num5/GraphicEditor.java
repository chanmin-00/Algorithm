package num5;

import java.util.Scanner;

abstract class Shape {
	private Shape next;

	public Shape() {
		next = null;
	}

	public void setNext(Shape obj) {
		next = obj;
	} // 링크 연결

	public Shape getNext() {
		return next;
	}

	public abstract void draw();
}

class Line extends Shape {
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Line");
	}
}

class Rect extends Shape {
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Rect");
	}
}

class Circle extends Shape {
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Circle");
	}
}

public class GraphicEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("그래픽 에디터 beauty를 실행합니다.");
		Scanner sc = new Scanner(System.in);
		Shape start = null, last = null, obj = null;
		while (true) {
			System.out.print("삽입(1),삭제(2),모두 보기(3),종료(4)>>");
			int tmp1 = 0;
			while (true) {
				try {
					tmp1 = sc.nextInt();
					if (tmp1 >= 1 && tmp1 <= 4)
						break;
				} catch (Exception e) {
					System.out.println("예외 발생");
				}
				System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
			}
			if (tmp1 == 1) {
				System.out.print("Line(1),Rect(2),Circle(3)>>");
				int tmp2 = 0;
				while (true) {
					try {
						tmp2 = sc.nextInt();
						if (tmp2 >= 1 && tmp2 <= 3)
							break;
					} catch (Exception e) {
						System.out.println("예외 발생");
					}
					System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
				}
				switch (tmp2) {
				case 1:
					obj = new Line();
					break;
				case 2:
					obj = new Rect();
					break;
				case 3:
					obj = new Circle();
					break;
				}
				if (start == null) {
					start = obj;
					last = obj;
				} else {
					last.setNext(obj);
					last = obj;
				}
			}
			// 삭제
			else if (tmp1 == 2) {
				System.out.print("삭제할 도형의 위치>>");
				int tmp2 = 0;
				while (true) {
					try {
						tmp2 = sc.nextInt();
						if (tmp2 > 0)
							break;
					} catch (Exception e) {
						System.out.println("예외 발생");
					}
					System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
				}
				Shape p_1 = start;
				Shape p_2 = start;
				try {
					if (tmp2 == 1) {
						if (start == last) {
							start = null;
							last = null;
						} else
							start = start.getNext();
					} else {
						for (int i = 1; i < tmp2; i++) {
							p_1 = p_1.getNext();
						}
						for (int i = 1; i < tmp2 - 1; i++) {
							p_2 = p_2.getNext();
						}
						if (p_1 == null) {
							System.out.println("삭제할 수 없습니다.");
						} else {
							if (p_1 == last) {
								p_2.setNext(p_1.getNext());
								last = p_2;
							} else
								p_2.setNext(p_1.getNext());
						}
					}
				} catch (Exception e) {
					System.out.println("삭제할 수 없습니다.");
				}

			} else if (tmp1 == 3) {
				Shape p = start;
				while (p != null) {
					p.draw();
					p = p.getNext();
				}
			} else {
				System.out.println("beauty을 종료합니다");
				break;
			}

		}
		sc.close();
	}

}
