package num10;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class num10_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		HashMap<String, Integer> h = new HashMap<String, Integer>();
		System.out.println("**포인트 관리 프로그램입니다**");
		while (true) {
			System.out.print("이름과 포인트 입력>>");
			String name = sc.next();
			if (name.equals("그만"))
				break;
			int score = sc.nextInt();
			if (h.get(name) == null) {
				h.put(name, score);
			} else {
				h.put(name, h.get(name) + score);
			}

			Set<String> keys2 = h.keySet();
			Iterator<String> it2 = keys2.iterator();
			while (it2.hasNext()) {
				String tmp2 = it2.next();
				System.out.print("(" + tmp2 + "," + h.get(tmp2) + ")");
			}
			System.out.println();

		}
		sc.close();
	}

}
