package num10;

import java.util.Scanner;
import java.util.Vector;

public class num10_4 {

	public static void printRain(Vector<Integer> v) {
		int sum = 0;
		for (int i = 0; i < v.size(); i++) {
			System.out.print(v.get(i) + " ");
			sum += v.get(i);
		}
		System.out.println();
		System.out.println("현재 평균 " + sum / v.size());

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Vector<Integer> rain = new Vector<Integer>();
		while (true) {
			System.out.print("강수량 입력(0 입력시 종료)>>");
			int num = 0;
			try {
				num = sc.nextInt();
				if (num < 0) {
					System.out.println("잘못된 숫자 입력. 다시 입력하세요>>");
					continue;
				} else if (num == 0)
					break;
				else {
					rain.add(num);
					printRain(rain);
				}
			} catch (Exception e) {
				System.out.println("잘못된 숫자 입력. 다시 입력하세요>>");
				sc.nextLine();
				continue;
			}

		}
		sc.close();
	}

}
