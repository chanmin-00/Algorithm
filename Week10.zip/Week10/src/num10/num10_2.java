package num10;

import java.util.ArrayList;
import java.util.Scanner;

public class num10_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		ArrayList<Character> grade = new ArrayList<Character>();
		double sum = 0.0;
		System.out.print("6개의 학점을 빈 칸으로 분리 입력(A/B/C/D/F) >>");
		for (int i = 0; i < 6; i++) {
			String grade_tmp = sc.next();
			char c_tmp = grade_tmp.charAt(0);
			grade.add(c_tmp);
		}
		for (int i = 0; i < grade.size(); i++) {
			char c = grade.get(i);
			switch (c) {
			case 'A':
				sum += 4.0;
				break;
			case 'B':
				sum += 3.0;
				break;
			case 'C':
				sum += 2.0;
				break;
			case 'D':
				sum += 1.0;
				break;
			case 'F':
				sum += 0;
				break;
			}
		}
		System.out.println(sum / 6);
		sc.close();

	}

}
