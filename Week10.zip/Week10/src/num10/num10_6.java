package num10;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

class Location {
	private String cityName;
	private int num1;
	private int num2;

	public Location(String city, int num1, int num2) {
		this.cityName = city;
		this.num1 = num1;
		this.num2 = num2;
	}

	public int getnum1() {
		return this.num1;
	}

	public int getnum2() {
		return this.num2;
	}

	public String getName() {
		return this.cityName;
	}
}

public class num10_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Location[] citys = new Location[4];
		Scanner sc = new Scanner(System.in);
		HashMap<String, Location> h = new HashMap<String, Location>();
		System.out.println("도시, 경도, 위도를 입력하세요.");
		for (int i = 0; i < citys.length; i++) {
			System.out.print(">>");
			String tmp = sc.nextLine();
			StringTokenizer st = new StringTokenizer(tmp, ",");
			String city = st.nextToken().trim();
			int num1 = Integer.parseInt(st.nextToken().trim());
			int num2 = Integer.parseInt(st.nextToken().trim());
			citys[i] = new Location(city, num1, num2);
			h.put(city, citys[i]);
		}
		System.out.println("-----------------");
		Set<String> keys = h.keySet();
		Iterator<String> it = keys.iterator();
		while (it.hasNext()) {
			String city = it.next();
			System.out.println(city + " " + h.get(city).getnum1() + " " + h.get(city).getnum2());
		}
		System.out.println("-----------------");

		while (true) {
			boolean jump = false;
			Set<String> keys2 = h.keySet();
			Iterator<String> it2 = keys2.iterator();
			System.out.print("도시이름>>");
			String city = sc.next();
			if (city.equals("그만"))
				break;
			while (it2.hasNext()) {
				String name = it2.next();
				if (city.equals(h.get(name).getName())) {
					System.out.println(city + " " + h.get(name).getnum1() + " " + h.get(name).getnum2());
					jump = true;
					break;
				}
			}
			if (jump == false)
				System.out.println(city + "는 없습니다.");
		}
		sc.close();

	}

}
