package num6;

import java.util.Scanner;

class Person {

	int num1, num2, num3;
	String name, s;
	Scanner sc_1 = new Scanner(System.in);

	public Person(String name) {
		this.name = name;
	}

	public boolean enter() {
		System.out.print("[" + name + "]:");
		s = sc_1.nextLine();
		num1 = (int) (Math.random() * 3 + 1);
		num2 = (int) (Math.random() * 3 + 1);
		num3 = (int) (Math.random() * 3 + 1);
		System.out.print(num1 + " ");
		System.out.print(num2 + " ");
		System.out.print(num3 + " ");
		if (num1 == num2 && num2 == num3) {
			System.out.println(name + "님이 이겼습니다!");
			return true;
		} else {
			System.out.println("아쉽군요!");
			return false;
		}
	}
}

public class Gambling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name_tmp;
		Scanner sc_2 = new Scanner(System.in);
		System.out.print("1번째 선수 이름>>");
		name_tmp = sc_2.next();
		Person p_1 = new Person(name_tmp);
		System.out.print("2번째 선수 이름>>");
		name_tmp = sc_2.next();
		Person p_2 = new Person(name_tmp);

		while (true) {
			if (p_1.enter()) {
				break;
			} else if (p_2.enter()) {
				break;
			}
		}
		sc_2.close();

	}

}
