package num6;

import java.util.Scanner;

public class Circling {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("문자열을 입력하세요. 빈칸이나 있어도 되고 영어 한글 모두 됩니다.");
		String s = sc.nextLine();
		for (int i = 0; i < s.length(); i++) {
			s = s.concat("" + s.charAt(0));
			s = s.substring(1);
			System.out.println(s);
		}
		sc.close();
	}
}
