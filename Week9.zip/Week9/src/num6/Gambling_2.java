package num6;

import java.util.Scanner;

public class Gambling_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean result = false;
		Scanner sc = new Scanner(System.in);
		System.out.print("겜블링 게임에 참여할 선수 숫자>>");
		int player_count = sc.nextInt();
		String[] player_name = new String[player_count];
		Person[] player_make = new Person[player_count];
		for (int i = 0; i < player_count; i++) {
			System.out.print(i + 1 + "번째 선수 이름>>");
			player_name[i] = sc.next();
			player_make[i] = new Person(player_name[i]);
		}
		while (result == false) {
			for (int i = 0; i < player_make.length; i++) {
				if (player_make[i].enter()) {
					result = true;
					break;
				}
			}
		}
		sc.close();

	}

}
