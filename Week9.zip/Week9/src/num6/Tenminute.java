package num6;

import java.util.Calendar;
import java.util.Scanner;

class player {
	private String name;
	private int first, second;
	private int minus;
	private String sc;
	Calendar now = Calendar.getInstance();
	Scanner a = new Scanner(System.in);

	public player(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void printresult() {
		System.out.print(name + " 시작 키 >>");
		sc = a.nextLine();
		first = printsecond();
		System.out.print("10초 예상 후 키  >> ");
		sc = a.nextLine();
		second = printsecond();
		if (second >= first)
			minus = second - first;
		else
			minus = second + 60 - first;
	}

	public int printsecond() {
		System.out.print(" 현재 초 시간 = ");
		now = Calendar.getInstance();
		int second_result = now.get(Calendar.SECOND);
		System.out.println(second_result);
		return second_result;
	}

	public int getMinus() {
		return minus;
	}

}

public class Tenminute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("10초에 가까운 사람이 이기는 게임입니다.");
		player a1 = new player("황기태");
		player a2 = new player("이재문");

		a1.printresult();
		a2.printresult();
		System.out.print(a1.getName() + "의 결과 " + a1.getMinus() + "," + a2.getName() + "의 결과 " + a2.getMinus());
		System.out.print(", 승자는 ");
		if (Math.abs(a1.getMinus() - 10) > Math.abs(a2.getMinus() - 10))
			System.out.println(a2.getName());
		else if (Math.abs(a1.getMinus() - 10) < Math.abs(a2.getMinus() - 10))
			System.out.println(a1.getName());
		else
			System.out.println("무승부");

	}

}
