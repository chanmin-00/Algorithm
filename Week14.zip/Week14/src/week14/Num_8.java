package week14;

import java.io.File;

public class Num_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("c:\\");
		File[] subfiles = f.listFiles(); // 서브리스트들을 file배열로 리턴
		long iMax = -1L; // L은 long형에 대한 명시적 표시
		int inum = -1;
		for (int i = 0; i < subfiles.length; i++) {
			long sizef = subfiles[i].length();
			if (iMax <= sizef) {
				inum = i;
				iMax = sizef;
			}
		}
		System.out.println("가장 큰 파일은 c:\\" + subfiles[inum].getName() + " " + subfiles[inum].length() + "바이트");

	}
}
