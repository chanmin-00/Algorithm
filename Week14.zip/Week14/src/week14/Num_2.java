package week14;

import java.io.FileReader;
import java.io.IOException;

public class Num_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReader fin = null;
		System.out.println("c:\\temp\\phone.txt를 출력합니다.");
		try {
			fin = new FileReader("c:\\temp\\phone.txt");
			int c;
			while ((c = fin.read()) != -1) {
				System.out.print((char) c);
			}
			fin.close();
		} catch (IOException e) {
			System.out.println("입출력 오류");
		}
	}

}
