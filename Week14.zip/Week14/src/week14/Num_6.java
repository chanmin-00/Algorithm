package week14;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Num_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("전체 경로명이 아닌 파일 이름만 입력하는 경우, 파일은 프로젝트 폴더에 있어야 합니다.");
		Scanner sc = new Scanner(System.in);
		FileInputStream fin1 = null;
		FileInputStream fin2 = null;
		FileOutputStream fout = null;
		System.out.print("첫 번째 파일 이름을 입력하세요>>");
		String name1 = sc.next();
		System.out.print("두 번째 파일 이름을 입력하세요>>");
		String name2 = sc.next();

		try {
			fin1 = new FileInputStream(name1);
			fin2 = new FileInputStream(name2);
			fout = new FileOutputStream("append.txt");
			byte[] buf1 = new byte[1024 * 10]; // 10KB 버퍼, 파일을 읽을 때 바이트 단위로 임시 저장 후 한번에 입력
			byte[] buf2 = new byte[1024 * 10];
			while (true) {
				int n = fin1.read(buf1); // n에는 읽어들인 바이트 수가 저장됨
				fout.write(buf1, 0, n); // buf1에 있는 것 가져와서 fout에 씀
				if (n < buf1.length)
					break;
			}
			while (true) {
				int n = fin2.read(buf2); // 읽어서 buf2에 byte로 임시 저장
				fout.write(buf2, 0, n);
				if (n < buf2.length)
					break;
			}
			fin1.close();
			fin2.close();
			fout.close();
			System.out.println("프로젝트 폴더 밑에 append.txt 파일에 저장했습니다.");
		} catch (IOException e) {
			System.out.println("입출력 오류");
		}
		sc.close();
	}

}
