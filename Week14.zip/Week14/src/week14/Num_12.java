package week14;

import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

public class Num_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> vector = new Vector<String>();
		Scanner sc = new Scanner(System.in);
		System.out.println("전체 경로명이 아닌 파일 이름만 입력하는 경우, 파일은 프로젝트 폴더에 있어야 합니다.");
		System.out.print("대상 파일명 입력>>");
		String name = sc.next();

		try {
			Scanner new_sc = new Scanner(new FileReader(name));
			while (new_sc.hasNext()) {
				String tmp = new_sc.nextLine();
				vector.add(tmp);
			}
		} catch (IOException e) {
			System.out.println("입출력 오류");
		}
		while (true) {
			System.out.print("검색할 단어나 문장>>");
			String temp = sc.next(); // temp 검색할 단어나 문장
			if (temp.equals("그만")) {
				System.out.println("프로그램을 종료합니다");
				break;
			}
			Iterator<String> it = vector.iterator();
			int linecount = 0;
			while (it.hasNext()) {
				String temp_2 = it.next(); // temp2는 하나의 문장
				if (temp_2.contains(temp)) {
					System.out.println(linecount + ": " + temp_2);
				}
				linecount++;
			}

		}
		sc.close();

	}

}
