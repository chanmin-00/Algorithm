package week14;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Num_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		HashMap<String, String> ph = new HashMap<String, String>();
		try {
			Scanner new_sc = new Scanner(new FileReader("c:\\temp\\phone.txt"));
			while (new_sc.hasNext()) {
				String one = new_sc.nextLine();
				String[] oneArr = one.split(" ");
				ph.put(oneArr[0], oneArr[1]);
			}
		} catch (IOException e) {
			System.out.println("입출력 오류");
		}
		System.out.println("총 " + ph.size() + "개의 전화번호를 읽었습니다");
		while (true) {
			System.out.print("이름>>");
			String name = sc.next();
			if (name.equals("그만"))
				break;
			if (ph.containsKey(name))
				System.out.println(ph.get(name));
			else
				System.out.println("찾는 이름이 없습니다");
		}
		sc.close();
	}

}
