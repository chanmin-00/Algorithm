package week14;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Num_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Scanner fScanner = new Scanner(new FileReader("c:\\windows\\system.ini"));
			int c = 0;
			while (fScanner.hasNext()) {
				String line = fScanner.nextLine();
				c++;
				System.out.printf("%4d" + ": " + line, c);
				System.out.println();
			}
		} catch (IOException e) {
			System.out.println("입출력오류");
		}
	}

}
