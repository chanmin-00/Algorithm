package week4;

import java.util.Scanner;

class Phone {
	private String name, tel;

	public Phone(String name, String tel) {
		this.name = name;
		this.tel = tel;
	}

	public String getName() {
		return name;
	}

	public String getTel() {
		return tel;
	}
}

public class PhonBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("인원수>>");
		int p_num = sc.nextInt();
		Phone[] p_arr = new Phone[p_num];

		for (int i = 0; i < p_arr.length; i++) {
			System.out.print("이름과 전화번호(이름과 번호는 빈 칸없이 입력)>>");
			String tmp1 = sc.next();
			String tmp2 = sc.next();
			p_arr[i] = new Phone(tmp1, tmp2);
		}
		System.out.println("저장되었습니다...");

		while (true) {
			boolean compare = false;
			System.out.print("검색할 이름>>");
			String name_tmp = sc.next();
			if (name_tmp.equals("그만"))
				break;
			for (int i = 0; i < p_arr.length; i++) {
				if (name_tmp.equals(p_arr[i].getName())) {
					System.out.print(p_arr[i].getName() + "의 번호는 ");
					System.out.println(p_arr[i].getTel() + " 입니다.");
					compare = true;
					break;
				}
			}
			if (compare == false) {
				System.out.println(name_tmp + "이 없습니다");
			}
		}
		sc.close();
	}

}
