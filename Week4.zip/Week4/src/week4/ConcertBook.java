package week4;

import java.util.Scanner;

class Seat {
	private String[] s;
	private String[] a;
	private String[] b;

	public Seat() {
		s = new String[10];
		a = new String[10];
		b = new String[10];
		for (int i = 0; i < 10; i++) {
			s[i] = "___";
			a[i] = "___";
			b[i] = "___";
		}
	}

	public void setS(String name, int i) {
		s[i - 1] = name;
	}

	public void setA(String name, int i) {
		a[i - 1] = name;
	}

	public void setB(String name, int i) {
		b[i - 1] = name;
	}

	public void printS() {
		System.out.print("S>> ");
		for (int i = 0; i < 10; i++) {
			System.out.print(s[i] + " ");
		}
		System.out.println();
	}

	public void printA() {
		System.out.print("A>> ");
		for (int i = 0; i < 10; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();
	}

	public void printB() {
		System.out.print("B>> ");
		for (int i = 0; i < 10; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
	}

	public void book() {
		Scanner sc = new Scanner(System.in);
		System.out.print("좌석구분 S(1),A(2),B(3)>>");
		int seat_tmp = 0;
		int num_tmp = 0;
		while (true) {
			try {
				seat_tmp = sc.nextInt();
				if (seat_tmp == 1 || seat_tmp == 2 || seat_tmp == 3)
					break;
			} catch (Exception e) {
				System.out.println("예외발생>>");
				sc.nextLine();
			}
			System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");

		}
		if (seat_tmp == 1)
			printS();
		else if (seat_tmp == 2)
			printA();
		else
			printB();
		System.out.print("이름>>");
		String name_tmp = sc.next();
		System.out.print("번호>>");
		while (true) {
			try {
				num_tmp = sc.nextInt();
				if (num_tmp >= 1 && num_tmp <= 10)
					break;
			} catch (Exception e) {
				System.out.println("예외발생>>");
				sc.nextLine();
			}
			System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
		}

		if (seat_tmp == 1)
			setS(name_tmp, num_tmp);
		else if (seat_tmp == 2)
			setA(name_tmp, num_tmp);
		else
			setB(name_tmp, num_tmp);
	}

	public void printSeat() {
		printS();
		printA();
		printB();
		System.out.println("<<조회를 완료하였습니다>>");
	}

	public void cancelSeat() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.print("좌석 S:1,A:2,B:3>>");
			int seat_tmp = 0;
			boolean name_contains = false;
			while (true) {
				try {
					seat_tmp = sc.nextInt();
					if (seat_tmp == 1 || seat_tmp == 2 || seat_tmp == 3)
						break;
				} catch (Exception e) {
					System.out.println("예외발생>>");
					sc.nextLine();
				}
				System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
			}
			if (seat_tmp == 1)
				printS();
			else if (seat_tmp == 2)
				printA();
			else
				printB();
			System.out.print("이름>>");
			String name_tmp = sc.next();
			if (seat_tmp == 1) {
				for (int i = 0; i < 10; i++) {
					if (name_tmp.equals(s[i])) {
						s[i] = "___";
						name_contains = true;
					}
				}
			} else if (seat_tmp == 2) {
				for (int i = 0; i < 10; i++) {
					if (name_tmp.equals(a[i])) {
						a[i] = "___";
						name_contains = true;
					}
				}
			} else {
				for (int i = 0; i < 10; i++) {
					if (name_tmp.equals(b[i])) {
						b[i] = "___";
						name_contains = true;
					}
				}
			}
			if (name_contains)
				break;

			System.out.println("해당자가 없습니다. 취소과정을 다시 시작합니다");
		}
	}

}

public class ConcertBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("명품콘서트홀 예약 시스템입니다.");
		Seat seat = new Seat();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.print("예약:1,조회:2,취소:3,끝내기:4>>");
			int choose = 0;
			while (true) {
				try {
					choose = sc.nextInt();
					if (choose == 1 || choose == 2 || choose == 3 || choose == 4)
						break;
				} catch (Exception e) {
					System.out.println("예외발생>>");
					sc.nextLine();
				}
				System.out.print("잘못된 수를 입력하였습니다. 다시 입력하세요>>");
			}
			if (choose == 1) {
				seat.book();
			} else if (choose == 2) {
				seat.printSeat();
			} else if (choose == 3) {
				seat.cancelSeat();
			} else
				break;

		}
		sc.close();
	}

}
