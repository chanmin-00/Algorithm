package week3;

import java.util.Scanner;

public class prc3_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String course[] = { "Java", "C++", "HTML5", "컴퓨터구조", "안드로이드" };
		int score[] = { 95, 88, 76, 62, 55 };
		boolean jump = false;
		while (true) {
			System.out.print("과목 이름 >>");
			String tmp = sc.next();
			if (tmp.equals("그만")) {
				System.out.println("종료합니다");
				break;
			}
			for (int i = 0; i < course.length; i++) {
				if (tmp.equals(course[i])) {
					System.out.println(course[i] + "의 점수는 " + score[i]);
					jump = true;
				}
			}
			if (jump) {
				jump = false;
				continue;
			}
			System.out.println("없는 과목입니다.");

		}
		sc.close();
	}

}
