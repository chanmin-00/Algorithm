package week3;

public class prc3_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] intarr = new int[4][4];
		for (int i = 0; i < intarr.length; i++) {
			for (int j = 0; j < intarr[i].length; j++) {
				intarr[i][j] = 0;
			}
		}
		for (int i = 0; i < 10; i++) {
			int i_num = (int) (Math.random() * 4);
			int j_num = (int) (Math.random() * 4);
			if (intarr[i_num][j_num] != 0) {
				i--;
				continue;
			}
			intarr[i_num][j_num] = (int) (Math.random() * 10 + 1);
		}
		for (int i = 0; i < intarr.length; i++) {
			for (int j = 0; j < intarr.length; j++) {
				System.out.print(intarr[i][j] + " ");
			}
			System.out.println();
		}
	}

}
