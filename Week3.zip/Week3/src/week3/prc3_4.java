package week3;

import java.util.Scanner;

public class prc3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = "";
		char c;
		System.out.print("소문자 알파벳 하나를 입력하시오>>");
		while (true) {
			s = sc.next();
			c = s.charAt(0);
			if (c >= 'a' && c <= 'z') {
				break;
			}
			System.out.println("잘못 입력 : 다시 입력");
		}

		for (int i = 0; i <= c - 'a'; i++) {
			for (int j = 'a'; j <= c - i; j++) {
				System.out.print("" + (char) j);
			}
			System.out.println();
		}
		sc.close();

	}

}
