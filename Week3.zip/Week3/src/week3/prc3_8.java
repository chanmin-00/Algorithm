package week3;

import java.util.Scanner;

public class prc3_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count;
		boolean check = false;
		Scanner sc = new Scanner(System.in);
		System.out.print("정수 몇개?>>");
		while (true) {
			count = sc.nextInt();
			if (count >= 100 || count <= 0) {
				System.out.print("잘못 입력: 다시 입력>>");
				continue;
			}
			break;
		}
		int[] intarr = new int[count];
		for (int i = 0; i < intarr.length; i++) {
			int tmp = (int) (Math.random() * 100 + 1);
			if (i >= 1) {
				for (int j = 0; j < i; j++) {
					if (tmp == intarr[j])
						check = true;
				}
			}
			if (check) {
				i--;
				check = false;
				continue;
			}
			intarr[i] = tmp;
		}
		for (int i = 0; i < intarr.length; i++) {
			System.out.print(intarr[i] + " ");
			if ((i + 1) % 10 == 0)
				System.out.println();
		}
		sc.close();

	}

}
